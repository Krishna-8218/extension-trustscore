/**
 * popup.js
 * Tab navigation, review scraping, copy/download,
 * and NATIVE CANVAS charts (no external library).
 */

let scrapedReviews = [];

/* ══════════════════════════════
   TAB SWITCHING
══════════════════════════════ */
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
  });
});

/* ══════════════════════════════
   SCRAPE REVIEWS
══════════════════════════════ */
document.getElementById("btn-scrape").addEventListener("click", async () => {
  const btn = document.getElementById("btn-scrape");
  const statusBar = document.getElementById("status-bar");

  btn.disabled = true;
  btn.innerHTML = "<span>⏳</span> Scraping…";
  setStatus(statusBar, "loading", "Scraping reviews, please wait…");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.tabs.sendMessage(tab.id, { action: "SCRAPE_REVIEWS" }, (response) => {
    btn.disabled = false;
    btn.innerHTML = "<span>⚡</span> Scrape Reviews";

    if (chrome.runtime.lastError) {
      setStatus(statusBar, "error", "Content script not found — refresh the page first.");
      return;
    }
    if (!response || !response.reviews) {
      setStatus(statusBar, "error", "No response received.");
      return;
    }

    scrapedReviews = response.reviews;
    const count = scrapedReviews.length;

    if (count === 0) {
      setStatus(statusBar, "error", "No reviews found on this page.");
      renderEmptyReviews();
      return;
    }

    setStatus(statusBar, "success", `Found ${count} review${count !== 1 ? "s" : ""}. Switch to AI Summary to analyse.`);
    renderReviews(scrapedReviews);
    document.getElementById("action-row").style.display = "flex";
  });
});

function setStatus(bar, type, msg) {
  bar.className = "status-bar " + type;
  document.getElementById("status-text").textContent = msg;
}

/* ── Render review cards ── */
function renderReviews(reviews) {
  const list = document.getElementById("reviews-list");
  list.innerHTML = "";
  reviews.forEach((text) => {
    const sentiment = scoreReview(text);
    const badgeClass = sentiment === "positive" ? "pos" : sentiment === "negative" ? "neg" : "neu";
    const badgeLabel = sentiment.charAt(0).toUpperCase() + sentiment.slice(1);
    const card = document.createElement("div");
    card.className = "review-card";
    card.innerHTML = `<span class="badge ${badgeClass}">${badgeLabel}</span><br/>${escapeHtml(text)}`;
    list.appendChild(card);
  });
}

function renderEmptyReviews() {
  document.getElementById("reviews-list").innerHTML = `
    <div class="empty-state">
      <div class="big">📦</div>
      <p>No reviews found.<br/>Try a product page.</p>
    </div>`;
  document.getElementById("action-row").style.display = "none";
}

function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/* ══════════════════════════════
   COPY / DOWNLOAD
══════════════════════════════ */
document.getElementById("btn-copy").addEventListener("click", () => {
  const json = JSON.stringify({ reviews: scrapedReviews }, null, 2);
  navigator.clipboard.writeText(json).then(() => {
    const b = document.getElementById("btn-copy");
    b.textContent = "✅ Copied!";
    setTimeout(() => { b.innerHTML = "📋 Copy JSON"; }, 1800);
  });
});

document.getElementById("btn-download").addEventListener("click", () => {
  const json = JSON.stringify({ reviews: scrapedReviews }, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "reviews.json"; a.click();
  URL.revokeObjectURL(url);
});

/* ══════════════════════════════
   ANALYSE → RENDER SUMMARY
══════════════════════════════ */
document.getElementById("btn-analyse").addEventListener("click", () => {
  const result = analyzeReviews(scrapedReviews);
  renderSummary(result);
});

function renderSummary(r) {
  const hasData = r.total > 0;
  document.getElementById("summary-prompt").style.display = hasData ? "none" : "block";
  document.getElementById("summary-content").style.display = hasData ? "block" : "none";
  if (!hasData) return;

  /* ── Verdict badge ── */
  const badge = document.getElementById("verdict-badge");
  badge.className = "verdict-badge " + (r.verdict === "N/A" ? "NA" : r.verdict);
  const icon = r.verdict === "BUY" ? "✅" : r.verdict === "SKIP" ? "❌" : r.verdict === "MIXED" ? "⚠️" : "—";
  badge.textContent = icon + " " + r.verdict;
  document.getElementById("verdict-summary").textContent = r.summary;

  /* ── Score ring ── */
  const offset = 188 - (r.score / 100) * 188;
  const ring = document.getElementById("ring-fg");
  ring.style.strokeDashoffset = offset;
  ring.style.stroke = r.verdict === "BUY" ? "#10b981" : r.verdict === "SKIP" ? "#ef4444" : "#f59e0b";
  document.getElementById("ring-pct").textContent = r.score + "%";

  /* ── Stat pills ── */
  document.getElementById("stat-pos").textContent = r.positive;
  document.getElementById("stat-neg").textContent = r.negative;
  document.getElementById("stat-neu").textContent = r.neutral;

  /* ── Legend text ── */
  const posP = r.total ? Math.round((r.positive / r.total) * 100) : 0;
  const negP = r.total ? Math.round((r.negative / r.total) * 100) : 0;
  const neuP = 100 - posP - negP;
  document.getElementById("leg-pos").textContent = `Positive – ${posP}%`;
  document.getElementById("leg-neg").textContent = `Negative – ${negP}%`;
  document.getElementById("leg-neu").textContent = `Neutral – ${neuP}%`;

  /* ── Draw charts ── */
  drawDonut(r.positive, r.negative, r.neutral, r.total);
  drawBar(r.categoryScores);
}

/* ══════════════════════════════
   NATIVE CANVAS: DONUT CHART
══════════════════════════════ */
function drawDonut(pos, neg, neu, total) {
  const canvas = document.getElementById("donut-canvas");
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  const cx = W / 2, cy = H / 2, r = W / 2 - 10, thickness = 18;

  /* background ring */
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.lineWidth = thickness;
  ctx.stroke();

  if (total === 0) return;

  const slices = [
    { value: pos, color: "#10b981" },
    { value: neg, color: "#ef4444" },
    { value: neu, color: "#4b5563" }
  ].filter(s => s.value > 0);

  let startAngle = -Math.PI / 2;
  slices.forEach(slice => {
    const sweep = (slice.value / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.arc(cx, cy, r, startAngle, startAngle + sweep);
    ctx.strokeStyle = slice.color;
    ctx.lineWidth = thickness;
    ctx.lineCap = "butt";
    ctx.stroke();
    startAngle += sweep;
  });

  /* Centre text */
  ctx.fillStyle = "#e8e8f0";
  ctx.font = "bold 16px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(total, cx, cy - 8);
  ctx.font = "10px Inter, sans-serif";
  ctx.fillStyle = "#6b7280";
  ctx.fillText("reviews", cx, cy + 10);
}

/* ══════════════════════════════
   NATIVE CANVAS: HORIZONTAL BAR CHART
══════════════════════════════ */
function drawBar(categoryScores) {
  const canvas = document.getElementById("bar-canvas");
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  const cats = Object.keys(categoryScores);
  if (cats.length === 0) return;

  const labelWidth = 68;
  const chartLeft = labelWidth + 8;
  const chartRight = W - 8;
  const chartW = chartRight - chartLeft;

  const rowH = Math.floor(H / cats.length);
  const barH = Math.min(12, rowH * 0.3);
  const gap = 3;

  /* find max value for scaling */
  let maxVal = 1;
  cats.forEach(c => {
    maxVal = Math.max(maxVal, categoryScores[c].pos, categoryScores[c].neg);
  });

  /* centre line x */
  const midX = chartLeft + chartW / 2;

  /* gridlines */
  ctx.strokeStyle = "rgba(255,255,255,0.05)";
  ctx.lineWidth = 1;
  [0, 0.25, 0.5, 0.75, 1].forEach(t => {
    const x = chartLeft + t * chartW;
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  });

  cats.forEach((cat, i) => {
    const rowY = i * rowH;
    const centerY = rowY + rowH / 2;

    /* Category label */
    ctx.fillStyle = "#9ca3af";
    ctx.font = "10px Inter, sans-serif";
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    ctx.fillText(cat, labelWidth, centerY);

    const posVal = categoryScores[cat].pos;
    const negVal = categoryScores[cat].neg;

    const scale = chartW / 2 / maxVal;

    /* Positive bar (right of centre) */
    if (posVal > 0) {
      const barW = posVal * scale;
      const rx = midX;
      const ry = centerY - barH - gap / 2;
      roundRect(ctx, rx, ry, barW, barH, 3);
      ctx.fillStyle = "#10b981";
      ctx.fill();

      if (barW > 18) {
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.font = "8px Inter, sans-serif";
        ctx.textAlign = "left";
        ctx.textBaseline = "middle";
        ctx.fillText(posVal, rx + 4, ry + barH / 2);
      }
    }

    /* Negative bar (left of centre) */
    if (negVal > 0) {
      const barW = negVal * scale;
      const rx = midX - barW;
      const ry = centerY + gap / 2;
      roundRect(ctx, rx, ry, barW, barH, 3);
      ctx.fillStyle = "#ef4444";
      ctx.fill();

      if (barW > 18) {
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.font = "8px Inter, sans-serif";
        ctx.textAlign = "right";
        ctx.textBaseline = "middle";
        ctx.fillText(negVal, rx + barW - 4, ry + barH / 2);
      }
    }
  });

  /* Centre divider line */
  ctx.strokeStyle = "rgba(255,255,255,0.15)";
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(midX, 0); ctx.lineTo(midX, H); ctx.stroke();

  /* Legend labels at bottom */
  ctx.font = "9px Inter, sans-serif";
  ctx.fillStyle = "#ef4444";
  ctx.textAlign = "right";
  ctx.textBaseline = "bottom";
  ctx.fillText("← Negative", midX - 4, H - 2);

  ctx.fillStyle = "#10b981";
  ctx.textAlign = "left";
  ctx.fillText("Positive →", midX + 4, H - 2);
}

/* Helper: rounded rect path */
function roundRect(ctx, x, y, w, h, r) {
  if (w < 2 * r) r = w / 2;
  if (h < 2 * r) r = h / 2;
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/* ══════════════════════════════
   PREDICT PRICE LOGIC
══════════════════════════════ */
document.getElementById("btn-predict").addEventListener("click", () => {
  const btn = document.getElementById("btn-predict");
  btn.disabled = true;
  btn.innerHTML = "<span>⏳</span> Analyzing Trends…";
  
  // Simulate AI processing time
  setTimeout(() => {
    generatePricePrediction();
    btn.disabled = false;
    btn.innerHTML = "<span>🔮</span> Predict Price Drop";
  }, 1200);
});

function generatePricePrediction() {
  document.getElementById("predict-prompt").style.display = "none";
  document.getElementById("predict-content").style.display = "block";

  const now = new Date();
  
  const events = [
    { name: "New Year Sale", month: 0, date: 10 }, // Jan
    { name: "Valentine's Day Sale", month: 1, date: 14 },
    { name: "Spring Sale", month: 3, date: 15 }, // Apr
    { name: "Summer Sale", month: 5, date: 20 }, // Jun
    { name: "Prime Day / Mid-Year", month: 6, date: 15 }, // Jul
    { name: "Back to School", month: 7, date: 15 }, // Aug
    { name: "Autumn Sale", month: 9, date: 15 }, // Oct
    { name: "Black Friday / Cyber Monday", month: 10, date: 28 }, // Nov
    { name: "Holiday / Christmas Sale", month: 11, date: 20 }  // Dec
  ];

  let nextEvent = null;
  let daysUntil = 9999;
  
  for (const event of events) {
    let eventDate = new Date(now.getFullYear(), event.month, event.date);
    if (eventDate < now) {
      eventDate = new Date(now.getFullYear() + 1, event.month, event.date);
    }
    const diffTime = eventDate - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays >= 0 && diffDays < daysUntil) {
      daysUntil = diffDays;
      nextEvent = event;
    }
  }

  const dateStr = now.toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
  document.getElementById("predict-date").textContent = dateStr;
  document.getElementById("predict-event").textContent = nextEvent ? nextEvent.name : "Upcoming Sale";

  const badge = document.getElementById("predict-badge");
  const summary = document.getElementById("predict-summary");
  const explanation = document.getElementById("predict-explanation");

  if (daysUntil <= 14) {
    badge.className = "verdict-badge SKIP";
    badge.innerHTML = "✋ WAIT FOR DROP";
    summary.textContent = `A major price drop is highly likely in ${daysUntil === 0 ? "a few hours" : daysUntil + " days"}.`;
    explanation.textContent = `Our AI has analyzed the 365-day historical pricing trends for this category. Sellers typically slash prices by 15-30% during the ${nextEvent.name}. Since it's only ${daysUntil} days away, we strongly advise against buying right now.`;
  } else if (daysUntil <= 40) {
    badge.className = "verdict-badge MIXED";
    badge.innerHTML = "⚠️ HOLD OFF";
    summary.textContent = `Prices are expected to drop in about ${Math.round(daysUntil/7)} weeks.`;
    explanation.textContent = `Historical data shows seasonal price reductions around ${nextEvent.name}. If you can wait a few weeks, you could save approximately 10-20%. However, if you need it urgently, the current price is stable.`;
  } else {
    badge.className = "verdict-badge BUY";
    badge.innerHTML = "✅ BUY NOW";
    summary.textContent = "Prices are currently stable. Good time to buy.";
    explanation.textContent = `The AI detected no major sales events in the immediate future (next major event is ${nextEvent.name} in ${Math.round(daysUntil/30)} months). Price trends are currently flat and stable. It is safe to purchase now without fearing an imminent price drop.`;
  }
}