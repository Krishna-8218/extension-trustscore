/**
 * analyzer.js
 * Client-side review sentiment analyser – no API key required.
 * Uses curated keyword lists to score reviews and produce a verdict.
 */

const POSITIVE_KEYWORDS = [
  // Quality
  "excellent", "amazing", "awesome", "fantastic", "great", "good", "best",
  "superb", "outstanding", "perfect", "wonderful", "brilliant", "love",
  "loved", "nice", "beautiful", "stunning", "flawless", "premium", "top",
  // Value
  "worth", "value", "affordable", "cheap", "reasonable", "budget", "deal",
  // Delivery
  "fast", "quick", "on time", "early", "prompt", "speedy", "delivered",
  // Fit / Feel
  "comfortable", "soft", "smooth", "fit", "fits", "fitting", "perfect fit",
  "lightweight", "durable", "sturdy", "solid",
  // Taste (food)
  "delicious", "tasty", "yummy", "fresh", "crispy", "hot",
  // Satisfaction
  "satisfied", "happy", "recommend", "recommended", "repurchase", "again",
  "repeat", "buy again", "must buy", "impressed", "exceeded", "surprise"
];

const NEGATIVE_KEYWORDS = [
  // Quality
  "bad", "poor", "worst", "terrible", "horrible", "awful", "pathetic",
  "useless", "waste", "cheap quality", "broke", "broken", "damaged",
  "defective", "faulty", "fake", "duplicate", "counterfeit",
  // Value
  "expensive", "overpriced", "not worth", "rip off", "ripoff", "costly",
  // Delivery
  "late", "delayed", "missing", "lost", "wrong", "incorrect", "never arrived",
  // Fit / Feel
  "uncomfortable", "rough", "tight", "loose", "small", "large", "shrink",
  "faded", "stain", "smell", "odour", "itchy",
  // Taste (food)
  "stale", "cold", "burnt", "raw", "undercooked", "bland",
  // Dissatisfaction
  "disappointed", "disappointing", "regret", "return", "refund", "complaint",
  "cheated", "fraud", "scam", "beware", "avoid", "never again", "do not buy",
  "don't buy", "not recommended"
];

/* ── Keyword category buckets for bar chart ── */
const CATEGORIES = {
  "Quality":  { pos: ["excellent","great","best","premium","durable","flawless","perfect","amazing","superb"], neg: ["bad","poor","fake","broken","damaged","defective","cheap quality","faulty"] },
  "Value":    { pos: ["worth","affordable","deal","value","reasonable","budget"], neg: ["expensive","overpriced","not worth","rip off","costly"] },
  "Delivery": { pos: ["fast","quick","on time","early","prompt","delivered"], neg: ["late","delayed","missing","lost","never arrived"] },
  "Comfort":  { pos: ["comfortable","soft","smooth","fit","lightweight"], neg: ["uncomfortable","rough","tight","loose","itchy","smell"] },
  "Overall":  { pos: ["love","happy","recommend","impressed","must buy","buy again"], neg: ["disappointed","regret","fraud","scam","avoid","never again"] }
};

/* ── Tokenise & score a single review ── */
function scoreReview(text) {
  const lower = text.toLowerCase();
  let pos = 0, neg = 0;

  POSITIVE_KEYWORDS.forEach(kw => { if (lower.includes(kw)) pos++; });
  NEGATIVE_KEYWORDS.forEach(kw => { if (lower.includes(kw)) neg++; });

  if (pos > neg) return "positive";
  if (neg > pos) return "negative";
  return "neutral";
}

/* ── Count category hits across all reviews ── */
function categoryScores(reviews) {
  const scores = {};
  Object.keys(CATEGORIES).forEach(cat => { scores[cat] = { pos: 0, neg: 0 }; });

  reviews.forEach(text => {
    const lower = text.toLowerCase();
    Object.entries(CATEGORIES).forEach(([cat, { pos, neg }]) => {
      pos.forEach(kw => { if (lower.includes(kw)) scores[cat].pos++; });
      neg.forEach(kw => { if (lower.includes(kw)) scores[cat].neg++; });
    });
  });

  return scores;
}

/* ── Generate a short human-readable summary ── */
function buildSummary(verdict, total, posCount, negCount, catScores) {
  const topPos = Object.entries(catScores)
    .filter(([, v]) => v.pos > 0)
    .sort((a, b) => b[1].pos - a[1].pos)
    .slice(0, 2)
    .map(([k]) => k.toLowerCase())
    .join(" and ");

  const topNeg = Object.entries(catScores)
    .filter(([, v]) => v.neg > 0)
    .sort((a, b) => b[1].neg - a[1].neg)
    .slice(0, 2)
    .map(([k]) => k.toLowerCase())
    .join(" and ");

  const pct = Math.round((posCount / total) * 100);

  if (verdict === "BUY") {
    return `${pct}% of reviewers are satisfied${topPos ? ", especially praising " + topPos : ""}. Most buyers would recommend this product.`;
  }
  if (verdict === "SKIP") {
    return `${Math.round((negCount / total) * 100)}% of reviewers express dissatisfaction${topNeg ? ", mainly around " + topNeg : ""}. Consider alternatives before purchasing.`;
  }
  return `Reviews are mixed${topPos ? " — positives around " + topPos : ""}${topNeg ? ", concerns about " + topNeg : ""}. Weigh your priorities before buying.`;
}

/* ── Main export ── */
function analyzeReviews(reviews) {
  if (!reviews || reviews.length === 0) {
    return {
      positive: 0, negative: 0, neutral: 0,
      score: 0, verdict: "N/A",
      summary: "No reviews found. Please scrape reviews first.",
      categoryScores: {}
    };
  }

  let positive = 0, negative = 0, neutral = 0;

  reviews.forEach(r => {
    const sentiment = scoreReview(r);
    if (sentiment === "positive") positive++;
    else if (sentiment === "negative") negative++;
    else neutral++;
  });

  const total = reviews.length;
  // Weighted score: positive full weight, neutral half weight
  const score = Math.round(((positive + neutral * 0.5) / total) * 100);

  let verdict;
  if (score >= 65) verdict = "BUY";
  else if (score >= 40) verdict = "MIXED";
  else verdict = "SKIP";

  const catScores = categoryScores(reviews);
  const summary = buildSummary(verdict, total, positive, negative, catScores);

  return { positive, negative, neutral, total, score, verdict, summary, categoryScores: catScores };
}
