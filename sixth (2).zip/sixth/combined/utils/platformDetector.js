/**
 * platformDetector.js – detects the current e-commerce platform.
 */
function detectPlatform() {
  const host = window.location.hostname;
  if (host.includes("myntra"))       return "Myntra";
  if (host.includes("meesho"))       return "Meesho";
  if (host.includes("flipkart"))     return "Flipkart";
  if (host.includes("amazon"))       return "Amazon";
  if (host.includes("ajio"))         return "Ajio";
  if (host.includes("nykaa"))        return "Nykaa";
  if (host.includes("snapdeal"))     return "Snapdeal";
  if (host.includes("makemytrip"))   return "MakeMyTrip";
  if (host.includes("zomato"))       return "Zomato";
  if (host.includes("swiggy"))       return "Swiggy";
  return "Unknown";
}
