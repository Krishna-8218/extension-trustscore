/**
 * credibility.js – reviewer credibility scoring (0-100).
 * Uses on-page behaviour + optional historical profile data.
 */
function calculateCredibility(reviews) {
  if (!reviews || reviews.length === 0) return [];

  const reviewerStats = {};

  reviews.forEach(review => {
    const name = review.reviewerName || "Anonymous";
    if (!reviewerStats[name]) {
      reviewerStats[name] = { count: 0, ratings: [] };
    }
    reviewerStats[name].count++;
    reviewerStats[name].ratings.push(review.rating || 4);
  });

  return reviews.map(review => {
    const name = review.reviewerName || "Anonymous";
    const stats = reviewerStats[name];

    let localScore = 100;
    let historyScore = 100;

    // --- LOCAL: on-page behaviour ---
    // Frequency penalty if same name leaves many reviews
    if (stats.count > 2) localScore -= (stats.count - 2) * 20;

    // Extreme uniform rating bias
    const allSame = stats.ratings.every(r => r === stats.ratings[0]);
    if (allSame && (stats.ratings[0] === 1 || stats.ratings[0] === 5)) localScore -= 40;

    // --- HISTORICAL: profile data if fetched ---
    if (review.history) {
      const h = review.history;
      if (h.totalReviews > 200) {
        historyScore -= 30; // Possible review farm
      } else if (h.totalReviews < 3 && (review.rating === 5 || review.rating === 1)) {
        historyScore -= 20; // New/throwaway account
      }
      if (h.avgRating > 4.8 || h.avgRating < 1.5) {
        historyScore -= 20; // Always extreme ratings
      }
    } else if (name !== "Anonymous") {
      historyScore = 90; // Named, no history yet — neutral
    } else {
      historyScore = 60; // Anonymous base penalty
    }

    const finalCredibility = Math.max(0, Math.min(100,
      localScore * 0.4 + historyScore * 0.6
    ));

    return { ...review, credibilityScore: Math.round(finalCredibility) };
  });
}

if (typeof module !== 'undefined') {
  module.exports = { calculateCredibility };
}
