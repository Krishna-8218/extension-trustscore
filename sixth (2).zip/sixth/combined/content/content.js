/**
 * content.js – TrustScore v3.0 Combined Scraper
 * Fully synchronous DOM scraper for 10 platforms.
 * Returns: Array of { text, reviewerName, rating, date, profileUrl }
 */

console.log("[TrustScore] Content script loaded on:", window.location.hostname);

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {

  if (request.action !== "SCRAPE_REVIEWS") {
    return false;
  }

  var host = window.location.hostname;
  var reviews = [];

  try {

    /* ==================== MYNTRA ==================== */
    if (host.includes("myntra")) {
      var blocks = document.querySelectorAll(".user-review-reviewTextWrapper");
      blocks.forEach(function(el) {
        var text = el.innerText.trim();
        var parent = el.closest(".user-review-main");
        var nameEl = parent ? parent.querySelector(".user-review-userName") : null;
        var name = nameEl ? nameEl.innerText.trim() : "Anonymous";
        var profileUrl = (nameEl && nameEl.closest("a")) ? nameEl.closest("a").href : null;
        var ratingEl = parent ? parent.querySelector(".user-review-rating") : null;
        var rating = ratingEl ? (parseInt(ratingEl.innerText) || 5) : 5;
        var dateEl = parent ? parent.querySelector(".user-review-date") : null;
        var date = dateEl ? dateEl.innerText.trim() : null;
        if (text) reviews.push({ text: text, reviewerName: name, rating: rating, date: date, profileUrl: profileUrl });
      });
    }

    /* ==================== MEESHO ==================== */
    else if (host.includes("meesho")) {
      // Try rich card selector first
      var cards = document.querySelectorAll('[class*="ReviewCard"], [class*="review-card"]');
      if (cards.length > 0) {
        cards.forEach(function(block) {
          var textEl = block.querySelector('[class*="Comment__CommentText"], [class*="review-text"], [class*="ReviewText"]');
          var text = textEl ? textEl.innerText.trim() : "";
          var nameEl = block.querySelector('[class*="reviewer-name"], [class*="UserName"], [class*="reviewerName"]');
          var name = nameEl ? nameEl.innerText.trim() : "Anonymous";
          if (!text) text = block.innerText.split("\n").find(function(t) { return t.length > 15; }) || "";
          if (text && text.length > 5) reviews.push({ text: text, reviewerName: name, rating: 4, profileUrl: null });
        });
      }
      // Fallback: grab CommentText spans
      if (reviews.length === 0) {
        document.querySelectorAll('[class*="Comment__CommentText"]').forEach(function(el) {
          var text = el.innerText.trim();
          if (text) reviews.push({ text: text, reviewerName: "Anonymous", rating: 4, profileUrl: null });
        });
      }
    }

    /* ==================== FLIPKART ==================== */
    else if (host.includes("flipkart")) {
      // Strategy 1: look for review row containers
      var fkBlocks = document.querySelectorAll('div[class*="XVM_io"], div[class*="_27M-uM"], div[class*="dyS3X"]');

      // Strategy 2: Verified Purchase heuristic
      if (fkBlocks.length === 0) {
        var potentialBlocks = [];
        document.querySelectorAll("div").forEach(function(d) {
          if (d.innerText.includes("Verified Purchase") && d.childElementCount > 2 && d.innerText.length > 30) {
            potentialBlocks.push(d);
          }
        });
        fkBlocks = potentialBlocks.length > 0 ? potentialBlocks : fkBlocks;
      }

      fkBlocks.forEach(function(block) {
        // Find the longest leaf text (= review body)
        var allLeafs = block.querySelectorAll("div, span, p");
        var text = "";
        var maxLen = 0;
        allLeafs.forEach(function(te) {
          if (te.childElementCount === 0 && te.innerText.length > maxLen) {
            maxLen = te.innerText.length;
            text = te.innerText.trim();
          }
        });
        var nameEl = block.querySelector('p[class*="_2sc77"], p[class*="_2V5E9v"]');
        var name = nameEl ? nameEl.innerText.trim() : "Anonymous";
        var ratingEl = block.querySelector('div[class*="_3LWZlK"], div[class*="_31v8Ym"]');
        var rating = ratingEl ? (parseInt(ratingEl.innerText) || 5) : 5;
        var profileLink = block.querySelector('a[href*="/profile/"]');
        var profileUrl = profileLink ? profileLink.href : null;
        if (text && text.length > 10 && !reviews.some(function(r) { return r.text === text; })) {
          reviews.push({ text: text, reviewerName: name, rating: rating, profileUrl: profileUrl });
        }
      });

      // Strategy 3: catch-all via star ratings
      if (reviews.length === 0) {
        document.querySelectorAll('div[class*="_3LWZlK"]').forEach(function(s) {
          var parent = s.closest('div[class*="col"]');
          if (parent) {
            var lines = parent.innerText.split("\n");
            var t = lines.find(function(l) { return l.length > 20; });
            if (t) reviews.push({ text: t.trim(), reviewerName: "Verified User", rating: parseInt(s.innerText) || 5, profileUrl: null });
          }
        });
      }
    }

    /* ==================== AMAZON ==================== */
    else if (host.includes("amazon")) {
      var amzBlocks = document.querySelectorAll('div[data-hook="review"]');
      amzBlocks.forEach(function(block) {
        var bodyEl = block.querySelector('[data-hook="review-body"]');
        var text = bodyEl ? bodyEl.innerText.trim() : "";
        var profileLinkEl = block.querySelector(".a-profile");
        var name = profileLinkEl ? profileLinkEl.innerText.trim() : "Anonymous";
        var profileUrl = profileLinkEl ? profileLinkEl.href : null;
        var ratingEl = block.querySelector('[data-hook="review-star-rating"]');
        var ratingClass = ratingEl ? ratingEl.className : "";
        var ratingMatch = ratingClass.match(/a-star-(\d)/);
        var rating = ratingMatch ? parseInt(ratingMatch[1]) : 5;
        var dateEl = block.querySelector('[data-hook="review-date"]');
        var date = dateEl ? dateEl.innerText.trim() : null;
        if (text) reviews.push({ text: text, reviewerName: name, rating: rating, date: date, profileUrl: profileUrl });
      });
    }

    /* ==================== AJIO ==================== */
    else if (host.includes("ajio")) {
      document.querySelectorAll(".pdp-review__comment").forEach(function(el) {
        var text = el.innerText.trim();
        if (text) reviews.push({ text: text, reviewerName: "Anonymous", rating: 4, profileUrl: null });
      });
    }

    /* ==================== NYKAA ==================== */
    else if (host.includes("nykaa")) {
      // Try multiple selector strategies
      var nykSelectors = ["p.css-1n0nrdk", '[class*="reviewText"]', '[class*="review-body"]', '[class*="ReviewBody"]'];
      for (var i = 0; i < nykSelectors.length; i++) {
        var els = document.querySelectorAll(nykSelectors[i]);
        if (els.length > 0) {
          els.forEach(function(el) {
            var text = el.innerText.trim();
            if (text && text.length > 10) reviews.push({ text: text, reviewerName: "Anonymous", rating: 4, profileUrl: null });
          });
          break;
        }
      }
    }

    /* ==================== SNAPDEAL ==================== */
    else if (host.includes("snapdeal")) {
      document.querySelectorAll(".user-review p").forEach(function(el) {
        var text = el.innerText.trim()
          .replace(/Verified Buyer/gi, "")
          .replace(/\n+/g, " ")
          .trim();
        if (text.length > 20) reviews.push({ text: text, reviewerName: "Anonymous", rating: 4, profileUrl: null });
      });
      // Deduplicate
      var seen = {};
      reviews = reviews.filter(function(r) {
        if (seen[r.text]) return false;
        seen[r.text] = true;
        return true;
      });
    }

    /* ==================== MAKEMYTRIP ==================== */
    else if (host.includes("makemytrip")) {
      document.querySelectorAll("p.reviewText, .reviewComment, .hotel-dt-city--review").forEach(function(el) {
        var text = el.innerText.trim();
        if (text && text.length > 10) reviews.push({ text: text, reviewerName: "Anonymous", rating: 4, profileUrl: null });
      });
    }

    /* ==================== ZOMATO ==================== */
    else if (host.includes("zomato")) {
      document.querySelectorAll("p").forEach(function(el) {
        var text = el.innerText.trim();
        if (
          text.length > 20 &&
          !text.includes("Votes") &&
          !text.includes("Comments") &&
          !text.includes("Create account") &&
          !text.includes("Reviews are better") &&
          !text.includes("Sign up") &&
          !text.includes("Download app")
        ) {
          reviews.push({ text: text, reviewerName: "Anonymous", rating: 4, profileUrl: null });
        }
      });
    }

    /* ==================== SWIGGY ==================== */
    else if (host.includes("swiggy")) {
      // Try multiple selectors since Swiggy updates classes often
      var swigSelectors = ["p._1n2p3", '[class*="reviewText"]', '[class*="review-content"]', '[class*="ReviewText"]'];
      for (var j = 0; j < swigSelectors.length; j++) {
        var swigEls = document.querySelectorAll(swigSelectors[j]);
        if (swigEls.length > 0) {
          swigEls.forEach(function(el) {
            var text = el.innerText.trim();
            if (text && text.length > 5) reviews.push({ text: text, reviewerName: "Anonymous", rating: 4, profileUrl: null });
          });
          break;
        }
      }
    }

  } catch (err) {
    console.error("[TrustScore] Scraper error:", err);
    sendResponse({ reviews: [] });
    return true;
  }

  console.log("[TrustScore] Found", reviews.length, "reviews on", host);
  sendResponse({ reviews: reviews });
  return true;

});
