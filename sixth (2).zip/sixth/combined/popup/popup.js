/**
 * popup.js – TrustScore v3.0
 * 3-Tab combined extension: Reviews · AI Summary · Trust Score
 */

var scrapedReviews = []; // { text, reviewerName, rating, date, profileUrl }

/* ══════════════════════════════════════════
   INIT: Detect platform on load
══════════════════════════════════════════ */
chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  var tab = tabs[0];
  if (!tab || !tab.url) return;
  try {
    var host = new URL(tab.url).hostname;
    var platformMap = {
      myntra: "Myntra", meesho: "Meesho", flipkart: "Flipkart",
      amazon: "Amazon", ajio: "Ajio", nykaa: "Nykaa",
      snapdeal: "Snapdeal", makemytrip: "MakeMyTrip",
      zomato: "Zomato", swiggy: "Swiggy"
    };
    var badge = document.getElementById("platform-badge");
    var found = Object.keys(platformMap).find(function(k) { return host.includes(k); });
    if (found) {
      badge.textContent = "\uD83D\uDD17 " + platformMap[found];
      badge.style.color = "#34d399";
    } else {
      badge.textContent = "Not Supported";
      badge.style.color = "#f59e0b";
    }
  } catch(e) { /* ignore */ }
});

/* ══════════════════════════════════════════
   TAB SWITCHING
══════════════════════════════════════════ */
document.querySelectorAll(".tab-btn").forEach(function(btn) {
  btn.addEventListener("click", function() {
    document.querySelectorAll(".tab-btn").forEach(function(b) { b.classList.remove("active"); });
    document.querySelectorAll(".tab-panel").forEach(function(p) { p.classList.remove("active"); });
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
  });
});

/* ══════════════════════════════════════════
   REVIEWS TAB — SCRAPE
══════════════════════════════════════════ */
document.getElementById("btn-scrape").addEventListener("click", function() {
  var btn = document.getElementById("btn-scrape");
  btn.disabled = true;
  btn.innerHTML = "<span>\u23F3</span> Scraping\u2026";
  setStatus("reviews-status-bar", "reviews-status-text", "loading", "Scraping reviews, please wait\u2026");

  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var tab = tabs[0];
    if (!tab) {
      btn.disabled = false;
      btn.innerHTML = "<span>\u26A1</span> Scrape Reviews";
      setStatus("reviews-status-bar", "reviews-status-text", "error", "Cannot access current tab.");
      return;
    }

    chrome.tabs.sendMessage(tab.id, { action: "SCRAPE_REVIEWS" }, function(response) {
      btn.disabled = false;
      btn.innerHTML = "<span>\u26A1</span> Scrape Reviews";

      if (chrome.runtime.lastError) {
        setStatus("reviews-status-bar", "reviews-status-text", "error",
          "Could not connect to page. Please REFRESH the page and try again.");
        return;
      }
      if (!response || !response.reviews || response.reviews.length === 0) {
        setStatus("reviews-status-bar", "reviews-status-text", "error",
          "No reviews found. Scroll down to the reviews section first.");
        renderEmptyList();
        return;
      }

      scrapedReviews = response.reviews;
      var count = scrapedReviews.length;
      setStatus("reviews-status-bar", "reviews-status-text", "success",
        "Found " + count + " review" + (count !== 1 ? "s" : "") + ". Switch tabs to analyse.");
      renderReviews(scrapedReviews);
      document.getElementById("action-row").style.display = "flex";
    });
  });
});

function renderReviews(reviews) {
  var list = document.getElementById("reviews-list");
  list.innerHTML = "";
  reviews.forEach(function(r) {
    var text = typeof r === "string" ? r : (r.text || "");
    var name = (r && r.reviewerName) ? r.reviewerName : null;
    var rating = (r && r.rating) ? r.rating : null;
    var sentiment = scoreReview(r);
    var bc = sentiment === "positive" ? "pos" : sentiment === "negative" ? "neg" : "neu";
    var bl = sentiment.charAt(0).toUpperCase() + sentiment.slice(1);
    var card = document.createElement("div");
    card.className = "review-card";
    var meta = "";
    if (name || rating) {
      meta = '<div class="review-meta">';
      if (name) meta += "\uD83D\uDC64 " + esc(name);
      if (rating) meta += (name ? " \u00B7 " : "") + "\u2B50 " + rating + "/5";
      meta += "</div>";
    }
    card.innerHTML = '<span class="badge ' + bc + '">' + bl + '</span><br/>' + esc(text) + meta;
    list.appendChild(card);
  });
}

function renderEmptyList() {
  document.getElementById("reviews-list").innerHTML =
    '<div class="empty-state"><div class="big">\uD83D\uDCE6</div><p>No reviews found.<br/>Try a product page.</p></div>';
  document.getElementById("action-row").style.display = "none";
}

function esc(str) {
  return (str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

/* Copy & Download */
document.getElementById("btn-copy").addEventListener("click", function() {
  var json = JSON.stringify({ reviews: scrapedReviews }, null, 2);
  navigator.clipboard.writeText(json).then(function() {
    var b = document.getElementById("btn-copy");
    b.textContent = "\u2705 Copied!";
    setTimeout(function() { b.innerHTML = "\uD83D\uDCCB Copy JSON"; }, 1800);
  });
});

document.getElementById("btn-download").addEventListener("click", function() {
  var json = JSON.stringify({ reviews: scrapedReviews }, null, 2);
  var blob = new Blob([json], { type: "application/json" });
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url; a.download = "reviews.json"; a.click();
  URL.revokeObjectURL(url);
});

/* ══════════════════════════════════════════
   AI SUMMARY TAB — ANALYSE
══════════════════════════════════════════ */
document.getElementById("btn-analyse").addEventListener("click", function() {
  if (!scrapedReviews.length) {
    alert("Please scrape reviews first from the Reviews tab.");
    return;
  }
  var result = analyzeReviews(scrapedReviews);
  renderSummary(result);
});

function renderSummary(r) {
  var hasData = r.total > 0;
  document.getElementById("summary-prompt").style.display = hasData ? "none" : "block";
  document.getElementById("summary-content").style.display = hasData ? "block" : "none";
  if (!hasData) return;

  var badge = document.getElementById("verdict-badge");
  badge.className = "verdict-badge " + (r.verdict === "N/A" ? "NA" : r.verdict);
  var icon = r.verdict === "BUY" ? "\u2705" : r.verdict === "SKIP" ? "\u274C" : r.verdict === "MIXED" ? "\u26A0\uFE0F" : "\u2014";
  badge.textContent = icon + " " + r.verdict;
  document.getElementById("verdict-summary").textContent = r.summary;

  var offset = 188 - (r.score / 100) * 188;
  var ring = document.getElementById("ring-fg");
  ring.style.strokeDashoffset = offset;
  ring.style.stroke = r.verdict === "BUY" ? "#10b981" : r.verdict === "SKIP" ? "#ef4444" : "#f59e0b";
  document.getElementById("ring-pct").textContent = r.score + "%";

  document.getElementById("stat-pos").textContent = r.positive;
  document.getElementById("stat-neg").textContent = r.negative;
  document.getElementById("stat-neu").textContent = r.neutral;

  var posP = r.total ? Math.round((r.positive / r.total) * 100) : 0;
  var negP = r.total ? Math.round((r.negative / r.total) * 100) : 0;
  var neuP = 100 - posP - negP;
  document.getElementById("leg-pos").textContent = "Positive \u2013 " + posP + "%";
  document.getElementById("leg-neg").textContent = "Negative \u2013 " + negP + "%";
  document.getElementById("leg-neu").textContent = "Neutral \u2013 " + neuP + "%";

  drawDonut(r.positive, r.negative, r.neutral, r.total);
  drawBar(r.categoryScores);
}

/* ── Donut Chart ── */
function drawDonut(pos, neg, neu, total) {
  var canvas = document.getElementById("donut-canvas");
  var ctx = canvas.getContext("2d");
  var W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);
  var cx = W / 2, cy = H / 2, r = W / 2 - 10, T = 18;

  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(255,255,255,0.06)"; ctx.lineWidth = T; ctx.stroke();
  if (!total) return;

  var slices = [
    { v: pos, c: "#10b981" }, { v: neg, c: "#ef4444" }, { v: neu, c: "#4b5563" }
  ].filter(function(s) { return s.v > 0; });

  var start = -Math.PI / 2;
  slices.forEach(function(s) {
    var sweep = (s.v / total) * Math.PI * 2;
    ctx.beginPath(); ctx.arc(cx, cy, r, start, start + sweep);
    ctx.strokeStyle = s.c; ctx.lineWidth = T; ctx.lineCap = "butt"; ctx.stroke();
    start += sweep;
  });

  ctx.fillStyle = "#e8e8f0"; ctx.font = "bold 16px Inter,sans-serif";
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.fillText(total, cx, cy - 8);
  ctx.font = "10px Inter,sans-serif"; ctx.fillStyle = "#6b7280";
  ctx.fillText("reviews", cx, cy + 10);
}

/* ── Bar Chart ── */
function drawBar(catScores) {
  var canvas = document.getElementById("bar-canvas");
  var ctx = canvas.getContext("2d");
  var W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);
  var cats = Object.keys(catScores);
  if (!cats.length) return;

  var lw = 68, cl = lw + 8, cr = W - 8, cw = cr - cl;
  var rowH = Math.floor(H / cats.length), barH = Math.min(12, rowH * 0.3), gap = 3;
  var maxVal = 1;
  cats.forEach(function(c) { maxVal = Math.max(maxVal, catScores[c].pos, catScores[c].neg); });
  var midX = cl + cw / 2;

  ctx.strokeStyle = "rgba(255,255,255,0.05)"; ctx.lineWidth = 1;
  [0, 0.25, 0.5, 0.75, 1].forEach(function(t) {
    var x = cl + t * cw;
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  });

  cats.forEach(function(cat, i) {
    var rY = i * rowH, cY = rY + rowH / 2;
    ctx.fillStyle = "#9ca3af"; ctx.font = "10px Inter,sans-serif";
    ctx.textAlign = "right"; ctx.textBaseline = "middle";
    ctx.fillText(cat, lw, cY);

    var pv = catScores[cat].pos, nv = catScores[cat].neg;
    var scale = cw / 2 / maxVal;

    if (pv > 0) {
      var bw = pv * scale;
      rrect(ctx, midX, cY - barH - gap / 2, bw, barH, 3);
      ctx.fillStyle = "#10b981"; ctx.fill();
      if (bw > 18) { ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.font = "8px Inter,sans-serif"; ctx.textAlign = "left"; ctx.textBaseline = "middle"; ctx.fillText(pv, midX + 4, cY - barH / 2 - gap / 2); }
    }
    if (nv > 0) {
      var bwn = nv * scale;
      rrect(ctx, midX - bwn, cY + gap / 2, bwn, barH, 3);
      ctx.fillStyle = "#ef4444"; ctx.fill();
      if (bwn > 18) { ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.font = "8px Inter,sans-serif"; ctx.textAlign = "right"; ctx.textBaseline = "middle"; ctx.fillText(nv, midX - 4, cY + barH / 2 + gap / 2); }
    }
  });

  ctx.strokeStyle = "rgba(255,255,255,0.15)"; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(midX, 0); ctx.lineTo(midX, H); ctx.stroke();
  ctx.font = "9px Inter,sans-serif";
  ctx.fillStyle = "#ef4444"; ctx.textAlign = "right"; ctx.textBaseline = "bottom"; ctx.fillText("\u2190 Negative", midX - 4, H - 2);
  ctx.fillStyle = "#10b981"; ctx.textAlign = "left"; ctx.fillText("Positive \u2192", midX + 4, H - 2);
}

function rrect(ctx, x, y, w, h, r) {
  if (w < 2 * r) r = w / 2; if (h < 2 * r) r = h / 2;
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

/* ══════════════════════════════════════════
   TRUST SCORE TAB — DEEP SCAN
══════════════════════════════════════════ */
document.getElementById("btn-trust-scan").addEventListener("click", function() {
  var btn = document.getElementById("btn-trust-scan");
  var progressContainer = document.getElementById("progress-container");
  var progressBar = document.getElementById("progress-bar");

  if (!scrapedReviews.length) {
    setStatus("trust-status-bar", "trust-status-text", "error",
      "No reviews yet. Go to Reviews tab and scrape first.");
    return;
  }

  btn.disabled = true;
  btn.innerHTML = "<span>\u23F3</span> Scanning\u2026";
  setStatus("trust-status-bar", "trust-status-text", "loading", "Starting deep scan\u2026");
  progressContainer.style.display = "block";
  progressBar.style.width = "10%";

  // Step 1: Local credibility scoring (instant)
  progressBar.style.width = "40%";
  setStatus("trust-status-bar", "trust-status-text", "loading", "Calculating reviewer credibility\u2026");

  var enriched = calculateCredibility(scrapedReviews);
  var avgCred = enriched.length
    ? Math.round(enriched.reduce(function(s, r) { return s + r.credibilityScore; }, 0) / enriched.length)
    : 70;

  // Show interim result immediately
  updateTrustUI(75, avgCred);
  progressBar.style.width = "60%";

  // Step 2: Try ML API (with timeout)
  setStatus("trust-status-bar", "trust-status-text", "loading", "Connecting to AI model\u2026");

  var reviewTexts = scrapedReviews.map(function(r) { return typeof r === "string" ? r : r.text; });

  // Race: API vs 9-second timeout
  var apiDone = false;

  var timeoutId = setTimeout(function() {
    if (apiDone) return;
    apiDone = true;
    // API timed out — use local sentiment score
    var localResult = analyzeReviews(scrapedReviews);
    progressBar.style.width = "100%";
    updateTrustUI(localResult.score, avgCred);
    setStatus("trust-status-bar", "trust-status-text", "success",
      "\u2705 Complete (local analysis \u2014 AI model offline/slow).");
    cleanup();
  }, 9000);

  sendReviewsToAPI(reviewTexts).then(function(apiResult) {
    if (apiDone) return;
    apiDone = true;
    clearTimeout(timeoutId);
    if (apiResult && apiResult.platform_summary && typeof apiResult.platform_summary.platform_trust_score === "number") {
      var auth = apiResult.platform_summary.platform_trust_score;
      progressBar.style.width = "100%";
      updateTrustUI(auth, avgCred);
      setStatus("trust-status-bar", "trust-status-text", "success",
        "\u2705 Complete (AI model + reviewer history).");
    } else {
      var localResult2 = analyzeReviews(scrapedReviews);
      progressBar.style.width = "100%";
      updateTrustUI(localResult2.score, avgCred);
      setStatus("trust-status-bar", "trust-status-text", "success",
        "\u2705 Complete (local analysis \u2014 API response invalid).");
    }
    cleanup();
  }).catch(function(err) {
    if (apiDone) return;
    apiDone = true;
    clearTimeout(timeoutId);
    var localResult3 = analyzeReviews(scrapedReviews);
    progressBar.style.width = "100%";
    updateTrustUI(localResult3.score, avgCred);
    setStatus("trust-status-bar", "trust-status-text", "success",
      "\u2705 Complete (local analysis \u2014 " + err.message + ").");
    cleanup();
  });

  function cleanup() {
    setTimeout(function() { progressContainer.style.display = "none"; }, 1200);
    btn.disabled = false;
    btn.innerHTML = "<span>\uD83D\uDEE1\uFE0F</span> Run Trust Scan";
  }
});

function updateTrustUI(authenticity, credibility) {
  var finalScore = Math.round(authenticity * 0.6 + credibility * 0.4);
  var trustEl = document.getElementById("trust-score");
  var authEl = document.getElementById("authenticity-score");
  var credEl = document.getElementById("credibility-score");
  var contentRing = document.getElementById("content-ring");
  var reviewerRing = document.getElementById("reviewer-ring");

  animateCount(trustEl, 0, finalScore, "%");
  authEl.textContent = Math.round(authenticity) + "%";
  credEl.textContent = credibility + "%";

  var offset = function(s) { return 226 * (1 - s / 100); };
  contentRing.style.strokeDashoffset = offset(authenticity);
  reviewerRing.style.strokeDashoffset = offset(credibility);
}

function animateCount(el, start, end, suffix) {
  var cur = start; suffix = suffix || "";
  var step = Math.max(10, Math.abs(Math.floor(600 / (end - cur || 1))));
  var timer = setInterval(function() {
    if (cur < end) cur++; else if (cur > end) cur--; else clearInterval(timer);
    el.textContent = cur + suffix;
  }, step);
}

/* ── ML API ── */
function sendReviewsToAPI(reviewTexts) {
  var csv = "review_id,seller_id,rating,review_text,review_date\n";
  reviewTexts.forEach(function(text, i) {
    var clean = (text || "").replace(/"/g, '""');
    csv += i + ",demo_seller,5,\"" + clean + "\",2024-01-01\n";
  });
  var blob = new Blob([csv], { type: "text/csv" });
  var formData = new FormData();
  formData.append("file", blob, "reviews.csv");
  return fetch("https://trustscore-ml-model.onrender.com/api/analyze", {
    method: "POST",
    body: formData
  }).then(function(res) { return res.json(); });
}

/* ══════════════════════════════════════════
   SHARED HELPERS
══════════════════════════════════════════ */
function setStatus(barId, textId, type, msg) {
  var bar = document.getElementById(barId);
  bar.className = "status-bar " + type;
  document.getElementById(textId).textContent = msg;
}
