chrome.runtime.onInstalled.addListener(() => {
  console.log("TrustScore – Review Analyser v3.0 installed.");
});
